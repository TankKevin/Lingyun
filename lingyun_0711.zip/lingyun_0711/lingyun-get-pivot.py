print("""Data source: 
    lingyun-template.xlsx, 
    lingyun-output.xlsx""")

import os
import sys
import pandas as pd
from etl import etl_data
os.chdir(sys.path[0])


data = etl_data(pd.read_excel('lingyun-template.xlsx'))
data_explode = pd.read_excel('lingyun-output.xlsx')

with pd.ExcelWriter('lingyun-pivot.xlsx', mode='w', engine='openpyxl') as writer:

    sheet1 = data.groupby('区域').count().iloc[:, 0].rename('条数').reset_index()
    sheet1['占比'] = sheet1['条数'] / sheet1['条数'].sum()
    sheet1 = sheet1.sort_values('条数', ascending=False)
    sheet1.loc[-1] = ('总计', sheet1['条数'].sum(), 1)
    sheet1.to_excel(writer, '区域', index=None)

    sheet2 = data.groupby('客诉来源').count().iloc[:, 0].rename('条数').reset_index()
    sheet2['占比'] = sheet2['条数'] / sheet2['条数'].sum()
    sheet2 = sheet2.sort_values('条数', ascending=False)
    sheet2.loc[-1] = ('总计', sheet2['条数'].sum(), 1)
    sheet2.to_excel(writer, '客诉来源', index=None)

    sheet3 = data.groupby('用户评级').count().iloc[:, 0].rename('条数').reset_index()
    sheet3['占比'] = sheet3['条数'] / sheet3['条数'].sum()
    sheet3 = sheet3.sort_values('条数', ascending=False)
    sheet3.loc[-1] = ('总计', sheet3['条数'].sum(), 1)
    sheet3.to_excel(writer, '用户评级', index=None)

    sheet4 = data_explode.groupby('投诉事项-split').count().iloc[:, 0].rename('个数').reset_index().rename({'投诉事项-split': '问题类型'}, axis=1)
    sheet4['占比'] = sheet4['个数'] / sheet4['个数'].sum()
    sheet4 = sheet4.sort_values('个数', ascending=False)
    sheet4.loc[-1] = ('总计', sheet4['个数'].sum(), 1)
    sheet4.to_excel(writer, '问题类型', index=None)

    data_pivot = data_explode.groupby(['投诉事项-split', '区域']).count().iloc[:, 0].reset_index()
    data_pivot.columns = '问题类型 区域 个数'.split()
    data_pivot = data_pivot.pivot(index='问题类型', columns='区域', values='个数')

    data_pivot = data_pivot.reindex(sheet4.iloc[:, 0])
    data_pivot = data_pivot.reindex(data_explode.groupby('区域').count().iloc[:, 0].rename('个数').reset_index().sort_values('个数', ascending=False).iloc[:, 0], axis=1)
    data_pivot['总计'] = data_pivot.sum(axis=1)
    data_pivot.loc['总计'] = data_pivot.sum(axis=0)
    data_pivot.to_excel(writer, '问题类型-区域')

print('lingyun-pivot.xlsx is done. Enjoy your life!')