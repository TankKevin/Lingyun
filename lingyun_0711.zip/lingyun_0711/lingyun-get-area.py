print("""Data source: 
    lingyun-template.xlsx
    lingyun-output.xlsx""")

import os
import sys
import pandas as pd
import plotly.graph_objects as go
os.chdir(sys.path[0])


# Get data frame
data = pd.read_excel('lingyun-template.xlsx')
areas = data['区域'].value_counts()

data_explode = pd.read_excel('lingyun-output.xlsx')
rename_dict = {'投诉事项-split': '问题类型', '客诉来源': '问题个数'}
frame = data_explode.groupby(['反馈日期', '区域', '投诉事项-split']).count().iloc[:, 0].reset_index().rename(rename_dict, axis=1)
frame_all = frame.groupby(['反馈日期', '问题类型']).sum()['问题个数'].reset_index().reindex(frame.columns, axis=1)
frame_all['区域'] = '所有区域'
frame = pd.concat([frame, frame_all], axis=0, ignore_index=True)

with pd.ExcelWriter('lingyun-area.xlsx', mode='w', engine='openpyxl') as writer:
    start = min(frame['反馈日期']).strftime(r'%Y-%m-%d')
    end = max(frame['反馈日期']).strftime(r'%Y-%m-%d')
    for area in ['所有区域'] + list(areas.index):
        frame_area = frame[frame['区域'] == area]

        # Get pivot table
        frame_pivot = frame_area.pivot(index='问题类型', columns='反馈日期', values='问题个数')
        frame_pivot = frame_pivot.reindex(pd.date_range(start, end, freq='1D'), axis=1)
        frame_pivot.columns = pd.date_range(start, end, freq='1D').map(lambda x: x.strftime(r'%Y-%m-%d'))
        frame_pivot = frame_pivot.sort_index(key=lambda x: frame_pivot.sum(axis=1)[x], ascending=False)

        # Save to excel sheet
        frame_pivot_print = frame_pivot.copy()
        frame_pivot_print['总计'] = frame_pivot_print.sum(axis=1)
        frame_pivot_print.loc['总计'] = frame_pivot_print.sum(axis=0)
        frame_pivot_print.to_excel(writer, area)

        # Melt the pivot table and plot
        frame_melt = frame_pivot.reset_index().melt(id_vars='问题类型')
        frame_melt.columns = '问题类型 反馈日期 问题个数'.split()
        fig = go.Figure()
        topn = 10
        names_plot = frame_pivot.index[:topn] if len(frame_pivot.index) >= topn else frame_pivot.index
        for name in names_plot:
            group = frame_melt[frame_melt['问题类型'] == name]
            fig.add_trace(go.Scatter(
                x=group['反馈日期'],
                y=group['问题个数'],
                name=name,
                line=dict(shape='spline')
            ))
        title = area + '问题类型每日趋势 ' + start + '~' + end
        fig.update_layout(
            title=title, 
            legend=dict(orientation='h', yanchor='bottom', y=-.25),
            height=500,
            width=1000
        )
        fig.write_image('area-pictures/' + area + '.png', scale=1.5)


print("""Output: 
    1. Pictures in area-pictures
    2. lingyun-area.xlsx""")
print('Enjoy your life!')