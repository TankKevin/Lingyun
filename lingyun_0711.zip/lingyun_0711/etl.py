import pandas as pd


def etl_data(data_source):
    data = data_source.copy()
    for col in data.columns:
        if data[col].dtype == object:
            data[col] = data[col].map(str.strip)
    data['客诉来源'] = data['客诉来源'].map(str.title)
    data['客诉来源'] = data['客诉来源'].map(lambda s: s.upper() if s == 'Bbb' else s)
    return data

def lingyun(string):
    if pd.isnull(string):
        return ''
    if string.startswith('物流'):
        return '物流'
    if string.startswith('商品'):
        return '商品'
    if string.startswith('客服'):
        return '客服'
    if string.startswith('拉新') or string.startswith('活动'):
        return '活动'
    if string.startswith('订单'):
        return '订单'
    if string.startswith('风控'):
        return '风控'
    if string.startswith('广告'):
        return '广告'
    if string.startswith('评论'):
        return '评论'
    if string.startswith('产品') or string.startswith('网站'):
        return '产品'
    if string.startswith('优惠券'):
        return '优惠券'
    if string.startswith('法律') or string.startswith('安全'):
        return '法律风险'
    if '联系方式' in string:
        return '未找到客服联系方式'
    if '信息安全' in string:
        return '信息泄露/安全'
    if '盗版网站' in string:
        return '盗版网站'
    if '诈骗网站' in string:
        return '诈骗网站'
    if '盗刷' in string:
        return '盗刷'
    if '信息泄露' in string or '信息安全' in string:
        return '信息泄露/安全'
    if '邮件' in string or '短信' in string or '推送' in string or '消息' in string or '轰炸' in string:
        return '信息轰炸/推送'
    if '退货' in string or '退款' in string:
        return '退货退款'
    if '非平台' in string:
        return '非平台订单'
    return string