print("""Data source: 
    lingyun-template.xlsx""")

import os
import sys
import pandas as pd
import numpy as np
from etl import etl_data, lingyun
os.chdir(sys.path[0])


data = etl_data(pd.read_excel('lingyun-template.xlsx'))
data['投诉事项-source'] = data['投诉事项'].str.split('、')
data = data.explode('投诉事项-source')
data['投诉事项-split'] = data['投诉事项-source'].map(lingyun)
data.to_excel('lingyun-output.xlsx', index=False)

print('lingyun-output.xlsx is done. Enjoy your life!')
