print("""Data source: 
    lingyun-template.xlsx, 
    lingyun-output.xlsx""")

import os
import sys
import pandas as pd
from etl import etl_data

os.chdir(sys.path[0])

data = etl_data(pd.read_excel('lingyun-template.xlsx'))
data_explode = pd.read_excel('lingyun-output.xlsx')

c0 = data.groupby('区域').count().iloc[:, 0].rename('区域条数').reset_index()
c1 = data.groupby(['区域', '客诉来源']).count().iloc[:, 0].rename('客诉条数').reset_index()
c2 = data_explode.groupby(['区域', '客诉来源', '投诉事项-split']).count().iloc[:, 0].rename('一级问题个数').reset_index()
c3 = data_explode.groupby(['区域', '客诉来源', '投诉事项-source']).count().iloc[:, 0].rename('二级问题个数').reset_index()
c4 = data_explode.groupby(['区域', '客诉来源', '投诉事项-source', '用户评级']).count().iloc[:, 0].rename('个数').reset_index()

columns = '客诉来源 用户评级 区域 投诉事项-source 投诉事项-split'.split()
data_group = data_explode[columns].groupby(columns).count().reset_index()

for c in (c0, c1, c2, c3, c4):
    data_group = data_group.merge(c, how='left')

data_group = data_group.rename({'投诉事项-split': '一级问题类型', '投诉事项-source': '二级问题类型', '个数': '问题个数'}, axis=1)

data_group = data_group.sort_values('区域条数 区域 客诉条数 客诉来源 一级问题个数 一级问题类型 问题个数 用户评级'.split(), ascending=False)
data_group = data_group['区域	区域条数	客诉来源	客诉条数	一级问题类型	一级问题个数	问题个数 用户评级 二级问题类型'.split()]

for x, xn in ('区域 区域条数'.split(), '客诉来源	客诉条数'.split(), '一级问题类型	一级问题个数'.split()):
    data_group[x] = data_group[x] + ' ' + data_group[xn].astype(str)
    data_group = data_group.drop(xn, axis=1)
data_group.loc[-1] = ['总计 {}'.format(data.shape[0]), None, None, data_group['问题个数'].sum(), None, None]

data_group.to_excel('lingyun-statistics.xlsx', index=None)

print('lingyun-statistics.xlsx is done. Enjoy your life!')
